"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/chat.ts
var chat_exports = {};
__export(chat_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(chat_exports);
var SYSTEM_PROMPT = `You are Uganda Legal AI, an expert legal assistant specializing in Ugandan law. You provide accurate, clear, and helpful information about:
- Ugandan constitutional law and the 1995 Constitution
- Land law: the Land Act (Cap 227), Land Acquisition Act, Mailo, Freehold, Leasehold, and Customary tenure
- Contract law under the Contracts Act 2010
- Construction and infrastructure law, UNRA regulations
- Public procurement rules under the PPDA Act 2003 and PPDA Regulations 2014
- Employment and labour law: the Employment Act 2006, Labour Unions Act
- Company and commercial law: the Companies Act 2012
- Criminal law and procedure: Penal Code Act, Criminal Procedure Code Act
- Family law: the Marriage Act, Divorce Act, Children Act

When answering:
1. Be precise and cite specific Ugandan legislation, acts, or regulations where applicable (e.g. "Under Section 29 of the Land Act...")
2. Explain legal concepts in clear, plain language accessible to non-lawyers
3. Use well-structured Markdown with headings, bullet points, and bold key terms
4. Always note at the end: "This is general legal information. For advice on your specific situation, consult a qualified Ugandan advocate."
5. If asked about something outside Ugandan law, still be helpful but note the limitation`;
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Groq API key not configured. Add GROQ_API_KEY to your Netlify environment variables." })
    };
  }
  let body;
  try {
    body = JSON.parse(event.body ?? "{}");
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON body" }) };
  }
  const messages = body.messages ?? [];
  if (!messages.length) {
    return { statusCode: 400, body: JSON.stringify({ error: "No messages provided" }) };
  }
  const trimmed = messages.slice(-20);
  try {
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...trimmed
        ],
        max_tokens: 2048,
        temperature: 0.3
      })
    });
    if (!response.ok) {
      const errText = await response.text();
      return {
        statusCode: response.status,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: `OpenAI error: ${errText}` })
      };
    }
    const data = await response.json();
    const answer = data.choices[0]?.message?.content ?? "Sorry, I could not generate a response.";
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ answer })
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: msg })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
